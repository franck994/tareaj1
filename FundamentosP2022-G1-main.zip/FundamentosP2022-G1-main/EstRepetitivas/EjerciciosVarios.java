package EstRepetitivas;

import java.util.Scanner;

/**
 * EjerciciosVarios
 */
public class EjerciciosVarios {
    static Scanner leerT=new Scanner(System.in);

    public static int factorialN(int numero) {
        
        return 0;
    }


    public static void main(String[] args) {
        
    }
}